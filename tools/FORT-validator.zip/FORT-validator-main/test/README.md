# Unit Tests

You need `check` installed:

	sudo apt install check

Note: If you hadn't installed `check` when you ran `autogen.sh`, you will need to
run it again:

	cd ..
	./autogen.sh
	./configure

Run the tests with

	make check
