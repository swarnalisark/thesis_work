# FORT Validator

An RPKI Relying Party and RTR Server.

## Documentation

- [Home](https://nicmx.github.io/FORT-validator/index.html)
- [Installation](https://nicmx.github.io/FORT-validator/installation.html)
- [Usage](https://nicmx.github.io/FORT-validator/run.html)
- [Arguments](https://nicmx.github.io/FORT-validator/usage.html)

## Docker image

See the [docker/ directory](docker/).
