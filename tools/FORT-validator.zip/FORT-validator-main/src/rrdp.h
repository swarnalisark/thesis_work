#ifndef SRC_RRDP_H_
#define SRC_RRDP_H_

#include "types/uri.h"

int rrdp_update(struct rpki_uri *);

#endif /* SRC_RRDP_H_ */
