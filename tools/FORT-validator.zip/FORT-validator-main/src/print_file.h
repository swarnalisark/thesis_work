#ifndef SRC_PRINT_FILE_H_
#define SRC_PRINT_FILE_H_

int print_file(void);

#endif /* SRC_PRINT_FILE_H_ */
