#ifndef SRC_JSON_HANDLER_H_
#define SRC_JSON_HANDLER_H_

int set_config_from_file(char *);

#endif /* SRC_JSON_HANDLER_H_ */
