#ifndef SRC_CONFIG_CURL_OFFSET_H_
#define SRC_CONFIG_CURL_OFFSET_H_

#include "config/types.h"

extern const struct global_type gt_curl_offset;

#endif /* SRC_CONFIG_CURL_OFFSET_H_ */
