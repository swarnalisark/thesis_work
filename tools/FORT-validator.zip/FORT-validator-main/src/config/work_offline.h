#ifndef SRC_CONFIG_WORK_OFFLINE_H_
#define SRC_CONFIG_WORK_OFFLINE_H_

#include "config/types.h"

extern const struct global_type gt_work_offline;

#endif /* SRC_CONFIG_WORK_OFFLINE_H_ */
