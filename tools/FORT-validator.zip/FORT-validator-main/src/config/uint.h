#ifndef SRC_CONFIG_UINT_H_
#define SRC_CONFIG_UINT_H_

#include "config/types.h"

extern const struct global_type gt_uint;

#endif /* SRC_CONFIG_UINT_H_ */
