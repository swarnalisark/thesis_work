#ifndef SRC_CONFIG_INCIDENCES_H_
#define SRC_CONFIG_INCIDENCES_H_

#include "config/types.h"

extern const struct global_type gt_incidences;

#endif /* SRC_CONFIG_INCIDENCES_H_ */
