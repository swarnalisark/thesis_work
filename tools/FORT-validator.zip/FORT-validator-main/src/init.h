#ifndef SRC_INIT_H_
#define SRC_INIT_H_

int download_tals(void);
int download_tal0s(void);

#endif /* SRC_INIT_H_ */
