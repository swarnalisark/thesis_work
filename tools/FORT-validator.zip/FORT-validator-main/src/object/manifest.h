#ifndef SRC_OBJECT_MANIFEST_H_
#define SRC_OBJECT_MANIFEST_H_

#include "rpp.h"

int handle_manifest(struct rpki_uri *, struct rpki_uri *, struct rpp **);

#endif /* SRC_OBJECT_MANIFEST_H_ */
