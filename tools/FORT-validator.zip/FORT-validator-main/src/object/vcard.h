#ifndef SRC_OBJECT_VCARD_H_
#define SRC_OBJECT_VCARD_H_

#include "asn1/asn1c/OCTET_STRING.h"

int handle_ghostbusters_vcard(OCTET_STRING_t *);

#endif /* SRC_OBJECT_VCARD_H_ */
