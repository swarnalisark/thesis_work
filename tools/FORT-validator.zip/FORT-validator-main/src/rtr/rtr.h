#ifndef RTR_RTR_H_
#define RTR_RTR_H_

int rtr_start(void);
void rtr_stop(void);

void rtr_notify(void);

#endif /* RTR_RTR_H_ */
