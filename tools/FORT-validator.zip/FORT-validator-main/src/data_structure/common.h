#ifndef SRC_DATA_STRUCTURE_COMMON_H_
#define SRC_DATA_STRUCTURE_COMMON_H_

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <unistd.h>

typedef size_t array_index;

#endif /* SRC_DATA_STRUCTURE_COMMON_H_ */
