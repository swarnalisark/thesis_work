#ifndef SRC_RSYNC_RSYNC_H_
#define SRC_RSYNC_RSYNC_H_

#include <stdbool.h>

int rsync_download(char const *, char const *, bool);

#endif /* SRC_RSYNC_RSYNC_H_ */
