#ifndef SRC_SLURM_SLURM_PARSER_H_
#define SRC_SLURM_SLURM_PARSER_H_

int slurm_parse(char const *, void *);

#endif /* SRC_SLURM_SLURM_PARSER_H_ */
