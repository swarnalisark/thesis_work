#ifndef SRC_OUTPUT_PRINTER_H_
#define SRC_OUTPUT_PRINTER_H_

#include "rtr/db/db_table.h"

void output_print_data(struct db_table const *);

#endif /* SRC_OUTPUT_PRINTER_H_ */
