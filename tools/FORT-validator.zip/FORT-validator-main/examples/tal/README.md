These TALs might be outdated. To download the latest versions, run

```bash
fort --init-tals --tal .
```

or download them manually:

- AFRINIC: https://afrinic.net/resource-certification/tal
- APNIC: https://www.apnic.net/community/security/resource-certification/tal-archive/
- ARIN: https://www.arin.net/resources/manage/rpki/tal/
- LACNIC: https://www.lacnic.net/4984/2/lacnic/rpki-rpki-trust-anchor
- RIPE NCC: https://www.ripe.net/manage-ips-and-asns/resource-management/rpki/ripe-ncc-rpki-trust-anchor-structure

